package com.example.imtidad

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.widget.Toast

object Social {
    fun toast(c: Context, s: String) {
        Toast.makeText(c, s, Toast.LENGTH_SHORT).show()
    }

    /** Creates (or reuses) the chat between me and the given username, then opens it. */
    fun startChat(a: Activity, name: String) {
        if (name.isEmpty()) { toast(a, "اكتب اسم المستخدم"); return }
        if (name == Fb.username(a)) { toast(a, "لا يمكنك مراسلة نفسك"); return }
        Thread {
            try {
                val found = Fb.findUserByName(a, name)
                if (found == null) {
                    a.runOnUiThread { toast(a, "لا يوجد مستخدم بهذا الاسم") }
                } else {
                    val me = Fb.uid(a)
                    val other = found.first
                    val chatId = listOf(me, other).sorted().joinToString("_")
                    Fb.create(a, "chats", chatId, Fb.doc(
                        Pair("members", Fb.av(listOf(me, other))),
                        Pair("names", Fb.av(listOf(Fb.username(a), name)))
                    ))
                    a.runOnUiThread {
                        a.startActivity(
                            Intent(a, ChatActivity::class.java)
                                .putExtra("chatId", chatId)
                                .putExtra("other", name)
                        )
                    }
                }
            } catch (e: Exception) {
                a.runOnUiThread { toast(a, e.message ?: "خطأ") }
            }
        }.start()
    }
}
