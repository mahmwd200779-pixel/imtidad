package com.example.imtidad

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Chats tab: list of conversations and a search box to start a new one. */
class ChatsTab(private val a: Activity) : ScrollView(a), Tab {
    private val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
    private val list = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
    private val search: EditText
    private val status: TextView
    private var lastSig = ""
    @Volatile private var busy = false

    init {
        val pad = Ui.dp(a, 12)
        col.setPadding(pad, pad, pad, pad)

        val card = Ui.card(a)
        card.addView(Ui.text(a, "محادثة جديدة", 14f, Ui.CYAN, true))
        search = Ui.input(a, "اسم المستخدم")
        card.addView(search, Ui.lp(a, 8))
        card.addView(Ui.btn(a, "ابدأ محادثة") {
            Social.startChat(a, search.text.toString().trim().lowercase())
        }, Ui.lp(a, 8))
        status = Ui.text(a, "", 12f, Color.RED)
        card.addView(status)
        col.addView(card)

        col.addView(Ui.text(a, "محادثاتك", 16f, Color.WHITE, true), Ui.lp(a, 16))
        col.addView(list, Ui.lp(a, 8))
        addView(col)
    }

    override fun refresh() {
        if (busy) return
        busy = true
        val me = Fb.uid(a)
        Thread {
            try {
                val chats = Fb.query(a, "chats", "members", "ARRAY_CONTAINS", Fb.sv(me), 100)
                val sig = chats.joinToString("|") { it.first }
                if (sig != lastSig) {
                    lastSig = sig
                    a.runOnUiThread { render(me, chats) }
                }
            } catch (e: Exception) {
                a.runOnUiThread { status.text = e.message ?: "تعذر التحديث" }
            } finally {
                busy = false
            }
        }.start()
    }

    private fun strs(v: Any?): List<String> =
        (v as? List<*>)?.map { (it as? String) ?: "" } ?: emptyList()

    private fun render(me: String, chats: List<Row>) {
        list.removeAllViews()
        if (chats.isEmpty()) {
            list.addView(Ui.text(a, "لا توجد محادثات بعد. ابحث عن صديق باسمه أعلاه.", 13f, Ui.MUTED))
            return
        }
        for ((id, m) in chats) {
            val members = strs(m["members"])
            val names = strs(m["names"])
            val i = members.indexOf(me)
            val other = (if (i == 0) names.getOrNull(1) else names.getOrNull(0)) ?: "محادثة"

            val row = Ui.card(a, 12)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.addView(Ui.avatar(a, other, 46))
            val label = Ui.text(a, "@$other", 16f, Color.WHITE, true)
            label.setPadding(Ui.dp(a, 12), 0, 0, 0)
            row.addView(label)
            row.setOnClickListener {
                a.startActivity(
                    Intent(a, ChatActivity::class.java)
                        .putExtra("chatId", id)
                        .putExtra("other", other)
                )
            }
            list.addView(row, Ui.lp(a, 8))
        }
    }
}
