package com.example.imtidad

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.LruCache
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.VideoView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Free media hosting through Cloudinary (unsigned upload preset) + simple image loading. */
object Media {
    private fun prefs(c: Context) = c.getSharedPreferences("imtidad", Context.MODE_PRIVATE)

    fun cloud(c: Context): String = prefs(c).getString("cloud", "") ?: ""
    fun preset(c: Context): String = prefs(c).getString("preset", "") ?: ""

    fun saveConfig(c: Context, cloudName: String, uploadPreset: String) {
        prefs(c).edit().putString("cloud", cloudName).putString("preset", uploadPreset).apply()
    }

    /** Uploads a photo or video and returns its public https URL. */
    fun upload(c: Context, uri: Uri, mime: String): String {
        val cloudName = cloud(c)
        val uploadPreset = preset(c)
        if (cloudName.isEmpty() || uploadPreset.isEmpty()) {
            throw Exception("أضف Cloud name و Upload preset في شاشة الدخول أولاً")
        }
        val kind = if (mime.startsWith("video")) "video" else "image"
        val boundary = "----imtidad${System.currentTimeMillis()}"
        val conn = URL("https://api.cloudinary.com/v1_1/$cloudName/$kind/upload").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.useCaches = false
        conn.connectTimeout = 30000
        conn.readTimeout = 180000
        conn.setChunkedStreamingMode(64 * 1024)
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")

        val out = conn.outputStream
        out.write("--$boundary\r\nContent-Disposition: form-data; name=\"upload_preset\"\r\n\r\n$uploadPreset\r\n".toByteArray())
        out.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"media\"\r\nContent-Type: $mime\r\n\r\n".toByteArray())
        val input = c.contentResolver.openInputStream(uri) ?: throw Exception("تعذر فتح الملف")
        input.use { it.copyTo(out) }
        out.write("\r\n--$boundary--\r\n".toByteArray())
        out.flush()
        out.close()

        val code = conn.responseCode
        val text = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
        if (code !in 200..299) throw Exception("فشل الرفع: " + text.take(200))
        return JSONObject(text).getString("secure_url")
    }

    private val cache = object : LruCache<String, Bitmap>(24) {}

    /** Loads an image URL into a view on a background thread (with a small in-memory cache). */
    fun loadInto(view: ImageView, url: String) {
        val hit = cache.get(url)
        if (hit != null) {
            view.setImageBitmap(hit)
            return
        }
        Thread {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 20000
                val opts = BitmapFactory.Options()
                opts.inSampleSize = 2
                val bmp = conn.inputStream.use { BitmapFactory.decodeStream(it, null, opts) }
                if (bmp != null) {
                    cache.put(url, bmp)
                    view.post { view.setImageBitmap(bmp) }
                }
            } catch (e: Exception) {
                // ignore; the placeholder stays
            }
        }.start()
    }

    /** Adds the post/story media (photo or video) to a parent layout, if any. */
    fun attach(a: Activity, parent: LinearLayout, m: Map<String, Any?>) {
        val url = (m["media"] as? String).orEmpty()
        if (url.isEmpty()) return
        val type = (m["mediaType"] as? String).orEmpty()
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(a, 230))
        lp.topMargin = Ui.dp(a, 10)
        if (type == "video") {
            val vv = VideoView(a)
            vv.setMediaController(MediaController(a))
            vv.setVideoURI(Uri.parse(url))
            parent.addView(vv, lp)
        } else {
            val iv = ImageView(a)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            loadInto(iv, url)
            parent.addView(iv, lp)
        }
    }

    /** Four buttons: gallery photo, gallery video, camera photo, camera video. */
    fun buttons(a: Activity, onGallery: (String) -> Unit, onCapture: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        val m = Ui.dp(a, 2)
        val labels = listOf("🖼 صورة", "🎥 فيديو", "📸 تصوير", "🎬 تسجيل")
        val actions: List<() -> Unit> = listOf(
            { onGallery("image/*") },
            { onGallery("video/*") },
            { onCapture(false) },
            { onCapture(true) }
        )
        for (i in labels.indices) {
            val b = Ui.btn(a, labels[i], Ui.FIELD) { actions[i]() }
            b.textSize = 12f
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(m, 0, m, 0)
            row.addView(b, lp)
        }
        return row
    }
}
