package com.example.imtidad

import android.app.Activity
import android.os.Bundle

/** Opens any user's profile by username. */
class ProfileActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val name = intent.getStringExtra("username") ?: Fb.username(this)
        val pv = ProfileView(this, name)
        pv.setBackgroundColor(0xFF0A0E14.toInt())
        setContentView(pv)
        pv.load(true)
    }
}
