package com.example.imtidad

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

object Ui {
    const val DAY_MS = 86400000L

    val COLORS: Array<IntArray> = arrayOf(
        intArrayOf(0xFFFF6A00.toInt(), 0xFFEE0979.toInt()),
        intArrayOf(0xFF00C6FF.toInt(), 0xFF0072FF.toInt()),
        intArrayOf(0xFF7F00FF.toInt(), 0xFFE100FF.toInt()),
        intArrayOf(0xFF11998E.toInt(), 0xFF38EF7D.toInt())
    )
    val CARD: Int = 0xFF121A26.toInt()
    val FIELD: Int = 0xFF1B2330.toInt()
    val MUTED: Int = 0xFF7F8C99.toInt()
    val ACCENT: Int = 0xFF2F80FF.toInt()
    val CYAN: Int = 0xFF00E5FF.toInt()

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun rounded(c: Context, color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(c, radius).toFloat()
        }

    fun gradient(c: Context, a: Int, b: Int, radius: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(a, b)).apply {
            cornerRadius = dp(c, radius).toFloat()
        }

    fun wrap(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    fun lp(c: Context, top: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(c, top)
        }

    fun btn(c: Context, label: String, color: Int = ACCENT, onClick: () -> Unit): Button =
        Button(c).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            textSize = 14f
            background = rounded(c, color, 12)
            setOnClickListener { onClick() }
        }

    fun input(c: Context, hintText: String, password: Boolean = false): EditText =
        EditText(c).apply {
            hint = hintText
            setTextColor(Color.WHITE)
            setHintTextColor(0x66FFFFFF.toInt())
            background = rounded(c, FIELD, 12)
            setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12))
            if (password) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

    fun card(c: Context, pad: Int = 14): LinearLayout =
        LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            val p = dp(c, pad)
            setPadding(p, p, p, p)
            background = rounded(c, CARD, 18)
        }

    fun text(c: Context, s: String, size: Float = 15f, color: Int = Color.WHITE, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    fun avatar(c: Context, name: String, size: Int): TextView {
        val idx = (name.hashCode() and 0x7fffffff) % COLORS.size
        return TextView(c).apply {
            text = name.take(1).uppercase()
            setTextColor(Color.WHITE)
            textSize = size / 2.6f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, COLORS[idx]).apply {
                shape = GradientDrawable.OVAL
            }
            layoutParams = LinearLayout.LayoutParams(dp(c, size), dp(c, size))
        }
    }

    /** Avatar with a gradient ring, like stories. */
    fun ring(c: Context, name: String, size: Int): LinearLayout {
        val idx = (name.hashCode() and 0x7fffffff) % COLORS.size
        return LinearLayout(c).apply {
            gravity = Gravity.CENTER
            val p = dp(c, 3)
            setPadding(p, p, p, p)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, COLORS[idx]).apply {
                shape = GradientDrawable.OVAL
            }
            addView(avatar(c, name, size - 6))
        }
    }

    fun timeAgo(ms: Long): String {
        if (ms <= 0L) return ""
        val d = (System.currentTimeMillis() - ms) / 1000
        return when {
            d < 60 -> "الآن"
            d < 3600 -> "منذ ${d / 60} د"
            d < 86400 -> "منذ ${d / 3600} س"
            else -> "منذ ${d / 86400} يوم"
        }
    }
}
