package com.example.imtidad

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout

object Ui {
    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun rounded(c: Context, color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(c, radius).toFloat()
        }

    fun btn(c: Context, label: String, color: Int = 0xFF2F80FF.toInt(), onClick: () -> Unit): Button =
        Button(c).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(c, color, 12)
            setOnClickListener { onClick() }
        }

    fun input(c: Context, hintText: String, password: Boolean = false): EditText =
        EditText(c).apply {
            hint = hintText
            setTextColor(Color.WHITE)
            setHintTextColor(0x88FFFFFF.toInt())
            background = rounded(c, 0xFF1B2330.toInt(), 12)
            setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12))
            if (password) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

    fun lp(c: Context, top: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(c, top)
        }
}
