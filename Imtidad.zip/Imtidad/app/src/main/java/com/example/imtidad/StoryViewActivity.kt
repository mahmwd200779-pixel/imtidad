package com.example.imtidad

import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.VideoView

/** Full-screen story viewer: one user's last-24h stories, one by one. */
class StoryViewActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private var items: List<Row> = emptyList()
    private var index = 0
    private lateinit var root: LinearLayout
    private lateinit var mediaImg: ImageView
    private lateinit var mediaVid: VideoView
    private lateinit var body: TextView
    private lateinit var counter: TextView
    private val auto = Runnable { advance() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val user = intent.getStringExtra("username") ?: ""
        val pad = Ui.dp(this, 16)

        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, Ui.dp(this, 36), pad, Ui.dp(this, 28))
        root.setBackgroundColor(0xFF0A0E14.toInt())
        root.setOnClickListener { advance() }

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(Ui.avatar(this, user, 36))
        val name = Ui.text(this, "@$user", 16f, Color.WHITE, true)
        name.setPadding(Ui.dp(this, 10), 0, 0, 0)
        top.addView(name)
        root.addView(top)

        counter = Ui.text(this, "", 12f, Ui.MUTED)
        root.addView(counter, Ui.lp(this, 6))

        val stage = FrameLayout(this)
        mediaImg = ImageView(this)
        mediaImg.scaleType = ImageView.ScaleType.CENTER_CROP
        mediaImg.visibility = View.GONE
        mediaVid = VideoView(this)
        mediaVid.visibility = View.GONE
        body = Ui.text(this, "جارٍ التحميل...", 26f, Color.WHITE, true)
        body.gravity = Gravity.CENTER
        stage.addView(mediaImg, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        stage.addView(mediaVid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        stage.addView(body, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(stage, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val hint = Ui.text(this, "اضغط للتالي", 12f, Ui.MUTED)
        hint.gravity = Gravity.CENTER
        root.addView(hint)
        setContentView(root)

        Thread {
            try {
                val now = System.currentTimeMillis()
                val list = Fb.query(this, "stories", "username", "EQUAL", Fb.sv(user), 100)
                    .filter { now - ((it.second["createdAt"] as? Long) ?: 0L) < Ui.DAY_MS }
                    .sortedBy { (it.second["createdAt"] as? Long) ?: 0L }
                runOnUiThread {
                    if (list.isEmpty()) {
                        finish()
                    } else {
                        items = list
                        show(0)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { finish() }
            }
        }.start()
    }

    private fun show(i: Int) {
        index = i
        ui.removeCallbacks(auto)
        val m = items[i].second
        val text = (m["text"] as? String) ?: ""
        val c = (((m["color"] as? Long) ?: 0L).toInt()).coerceIn(0, Ui.COLORS.size - 1)
        val url = (m["media"] as? String).orEmpty()
        val type = (m["mediaType"] as? String).orEmpty()

        root.background = Ui.gradient(this, Ui.COLORS[c][0], Ui.COLORS[c][1], 0)
        mediaImg.visibility = View.GONE
        mediaVid.stopPlayback()
        mediaVid.visibility = View.GONE
        body.text = text
        counter.text = "${i + 1} / ${items.size}"

        var delay = 5000L
        if (url.isNotEmpty()) {
            if (type == "video") {
                mediaVid.visibility = View.VISIBLE
                mediaVid.setVideoURI(Uri.parse(url))
                mediaVid.start()
                delay = 15000L
            } else {
                mediaImg.visibility = View.VISIBLE
                Media.loadInto(mediaImg, url)
            }
        }
        ui.postDelayed(auto, delay)
    }

    private fun advance() {
        if (index + 1 < items.size) show(index + 1) else finish()
    }

    override fun onDestroy() {
        ui.removeCallbacks(auto)
        super.onDestroy()
    }
}
