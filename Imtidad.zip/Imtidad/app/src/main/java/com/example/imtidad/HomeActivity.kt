package com.example.imtidad

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class HomeActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private lateinit var status: TextView
    @Volatile private var busy = false

    private val poll = object : Runnable {
        override fun run() {
            loadChats()
            ui.postDelayed(this, 4000L)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!Fb.loggedIn(this)) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        val pad = Ui.dp(this, 16)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(0xFF0A0E14.toInt())
        }

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = "امتداد"; textSize = 24f; setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(TextView(this).apply {
            text = "@" + Fb.username(this@HomeActivity); setTextColor(0xFF8FA3AD.toInt())
        })
        head.addView(Ui.btn(this, "خروج", 0xFF3A2230.toInt()) {
            Fb.logout(this)
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        })
        col.addView(head)

        status = TextView(this).apply { setTextColor(0xFFFF8A80.toInt()) }
        col.addView(status, Ui.lp(this, 6))

        search = Ui.input(this, "اسم المستخدم للبحث")
        col.addView(search, Ui.lp(this, 14))
        col.addView(Ui.btn(this, "ابدأ محادثة") { startChat() }, Ui.lp(this, 8))

        col.addView(TextView(this).apply {
            text = "المحادثات"; setTextColor(0xFF8FA3AD.toInt()); textSize = 14f
        }, Ui.lp(this, 18))

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list, Ui.lp(this, 6))

        val scroll = ScrollView(this)
        scroll.addView(col)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        ui.removeCallbacks(poll)
        ui.post(poll)
    }

    override fun onPause() {
        ui.removeCallbacks(poll)
        super.onPause()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun strings(v: Any?): List<String> =
        (v as? List<*>)?.map { (it as? String) ?: "" } ?: emptyList()

    private fun loadChats() {
        if (busy) return
        busy = true
        val me = Fb.uid(this)
        Thread {
            try {
                val chats = Fb.query(this, "chats", "members", "ARRAY_CONTAINS", Fb.sv(me))
                runOnUiThread {
                    status.text = ""
                    render(me, chats)
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = e.message ?: "تعذر التحديث" }
            } finally {
                busy = false
            }
        }.start()
    }

    private fun render(me: String, chats: List<Pair<String, Map<String, Any?>>>) {
        list.removeAllViews()
        if (chats.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "لا توجد محادثات بعد. ابحث عن صديق باسمه أعلاه."
                setTextColor(0xFF8FA3AD.toInt())
            })
            return
        }
        for ((id, m) in chats) {
            val members = strings(m["members"])
            val names = strings(m["names"])
            val i = members.indexOf(me)
            val other = (if (i == 0) names.getOrNull(1) else names.getOrNull(0)) ?: "محادثة"
            list.addView(Ui.btn(this, "@$other", 0xFF16202C.toInt()) {
                startActivity(Intent(this, ChatActivity::class.java).putExtra("chatId", id).putExtra("other", other))
            }, Ui.lp(this, 8))
        }
    }

    private fun startChat() {
        val name = search.text.toString().trim().lowercase()
        if (name.isEmpty()) return
        if (name == Fb.username(this)) { toast("لا يمكنك مراسلة نفسك"); return }
        Thread {
            try {
                val found = Fb.findUserByName(this, name)
                if (found == null) {
                    runOnUiThread { toast("لا يوجد مستخدم بهذا الاسم") }
                } else {
                    val me = Fb.uid(this)
                    val other = found.first
                    val chatId = listOf(me, other).sorted().joinToString("_")
                    val body = Fb.doc(
                        Pair("members", Fb.av(listOf(me, other))),
                        Pair("names", Fb.av(listOf(Fb.username(this), name)))
                    )
                    Fb.create(this, "chats", chatId, body)
                    runOnUiThread {
                        search.setText("")
                        startActivity(Intent(this, ChatActivity::class.java).putExtra("chatId", chatId).putExtra("other", name))
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast(e.message ?: "خطأ") }
            }
        }.start()
    }
}
