package com.example.imtidad

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Anything that can refresh its data while visible. */
interface Tab {
    fun refresh()
}

/** Main shell: top bar, page content, and bottom navigation with four tabs. */
class HomeActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private val pages = ArrayList<View>()
    private val navItems = ArrayList<TextView>()
    private lateinit var content: FrameLayout
    private var current = 0

    private val poll = object : Runnable {
        override fun run() {
            (pages.getOrNull(current) as? Tab)?.refresh()
            ui.postDelayed(this, 3000L)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!Fb.loggedIn(this)) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        val p = Ui.dp(this, 14)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF0A0E14.toInt())

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(p, p, p, Ui.dp(this, 6))
        top.addView(
            Ui.text(this, "امتداد", 22f, Color.WHITE, true),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        top.addView(Ui.avatar(this, Fb.username(this), 34))
        root.addView(top)

        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.setBackgroundColor(0xFF0F1622.toInt())
        nav.setPadding(Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 6), Ui.dp(this, 10))

        val labels = listOf("🏠 الرئيسية", "⭕ الستوري", "💬 المحادثات", "👤 حسابي")
        for (i in labels.indices) {
            val item = Ui.text(this, labels[i], 13f, Ui.MUTED)
            item.gravity = Gravity.CENTER
            item.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6))
            item.setOnClickListener { show(i) }
            navItems.add(item)
            nav.addView(item, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(nav)
        setContentView(root)

        pages.add(FeedTab(this))
        pages.add(StoriesTab(this))
        pages.add(ChatsTab(this))
        pages.add(ProfileView(this, Fb.username(this)))
        show(0)
    }

    private fun show(i: Int) {
        current = i
        content.removeAllViews()
        content.addView(pages[i], FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        for (j in navItems.indices) {
            val sel = j == i
            navItems[j].setTextColor(if (sel) Ui.CYAN else Ui.MUTED)
            navItems[j].setTypeface(null, if (sel) Typeface.BOLD else Typeface.NORMAL)
        }
        (pages[i] as? Tab)?.refresh()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        MediaPicker.handle(this, requestCode, resultCode, data)
    }

    override fun onResume() {
        super.onResume()
        ui.removeCallbacks(poll)
        ui.post(poll)
    }

    override fun onPause() {
        ui.removeCallbacks(poll)
        super.onPause()
    }
}
