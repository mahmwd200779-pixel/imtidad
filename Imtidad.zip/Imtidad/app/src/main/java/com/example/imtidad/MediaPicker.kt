package com.example.imtidad

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore

/** Opens the gallery or the camera and hands the result back through a callback. */
object MediaPicker {
    const val REQ = 4242

    private var onPicked: ((Uri, String) -> Unit)? = null
    private var pendingCapture: Uri? = null
    private var pendingMime = ""

    fun gallery(a: Activity, type: String, cb: (Uri, String) -> Unit) {
        onPicked = cb
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = type
        a.startActivityForResult(i, REQ)
    }

    /** Returns false if no camera app is available. */
    fun capture(a: Activity, video: Boolean, cb: (Uri, String) -> Unit): Boolean {
        val values = ContentValues()
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, "imtidad_${System.currentTimeMillis()}")
        values.put(MediaStore.MediaColumns.MIME_TYPE, if (video) "video/mp4" else "image/jpeg")
        val target = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val uri = a.contentResolver.insert(target, values) ?: return false
        val i = Intent(if (video) MediaStore.ACTION_VIDEO_CAPTURE else MediaStore.ACTION_IMAGE_CAPTURE)
        i.putExtra(MediaStore.EXTRA_OUTPUT, uri)
        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        onPicked = cb
        pendingCapture = uri
        pendingMime = if (video) "video/mp4" else "image/jpeg"
        return try {
            a.startActivityForResult(i, REQ)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun handle(a: Activity, code: Int, res: Int, data: Intent?) {
        if (code != REQ) return
        val cb = onPicked
        onPicked = null
        if (res != Activity.RESULT_OK) return
        val picked = data?.data
        val uri = picked ?: pendingCapture
        val mime = if (picked != null) (a.contentResolver.getType(picked) ?: "image/jpeg") else pendingMime
        if (uri != null && cb != null) cb(uri, mime)
    }
}
