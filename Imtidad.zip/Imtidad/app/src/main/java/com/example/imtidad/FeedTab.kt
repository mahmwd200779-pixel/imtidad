package com.example.imtidad

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Home tab: posts (text, photo or video) from everyone, with likes. */
class FeedTab(private val a: Activity) : ScrollView(a), Tab {
    private val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
    private val list = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
    private val input: EditText
    private val status: TextView
    private var pendingUri: Uri? = null
    private var pendingMime = ""
    private var lastSig = ""
    @Volatile private var busy = false

    init {
        val pad = Ui.dp(a, 12)
        col.setPadding(pad, pad, pad, pad)

        val composer = Ui.card(a)
        composer.addView(Ui.text(a, "شارك شيئاً مع الجميع", 14f, Ui.CYAN, true))
        input = Ui.input(a, "ماذا يدور في بالك؟")
        composer.addView(input, Ui.lp(a, 8))
        composer.addView(Media.buttons(a, { type -> pickGallery(type) }, { video -> capture(video) }), Ui.lp(a, 8))
        composer.addView(Ui.btn(a, "نشر") { publish() }, Ui.lp(a, 8))
        status = Ui.text(a, "", 12f, Color.RED)
        composer.addView(status)
        col.addView(composer)

        col.addView(list, Ui.lp(a, 12))
        addView(col)
    }

    private fun pickGallery(type: String) {
        MediaPicker.gallery(a, type) { uri, mime -> setPending(uri, mime) }
    }

    private fun capture(video: Boolean) {
        val ok = MediaPicker.capture(a, video) { uri, mime -> setPending(uri, mime) }
        if (!ok) status.text = "تعذر فتح الكاميرا على هذا الجهاز"
    }

    private fun setPending(uri: Uri, mime: String) {
        pendingUri = uri
        pendingMime = mime
        status.setTextColor(Ui.MUTED)
        status.text = if (mime.startsWith("video")) "🎥 فيديو جاهز للنشر" else "🖼 صورة جاهزة للنشر"
    }

    override fun refresh() {
        if (busy) return
        busy = true
        Thread {
            try {
                val me = Fb.uid(a)
                val posts = Fb.queryAll(a, "posts", 30, "createdAt")
                val likes = Fb.queryAll(a, "likes", 1000)
                val counts = HashMap<String, Int>()
                val mine = HashSet<String>()
                for ((_, m) in likes) {
                    val pid = (m["postId"] as? String) ?: continue
                    counts[pid] = (counts[pid] ?: 0) + 1
                    if (m["uid"] == me) mine.add(pid)
                }
                val sig = posts.joinToString("|") {
                    it.first + ":" + (counts[it.first] ?: 0) + ":" + mine.contains(it.first)
                }
                if (sig != lastSig) {
                    lastSig = sig
                    a.runOnUiThread { render(posts, counts, mine) }
                }
            } catch (e: Exception) {
                a.runOnUiThread { status.text = e.message ?: "تعذر التحديث" }
            } finally {
                busy = false
            }
        }.start()
    }

    private fun render(posts: List<Row>, counts: Map<String, Int>, mine: Set<String>) {
        list.removeAllViews()
        if (posts.isEmpty()) {
            list.addView(Ui.text(a, "لا توجد منشورات بعد. كن أول من ينشر!", 14f, Ui.MUTED))
            return
        }
        for ((id, m) in posts) {
            list.addView(postCard(id, m, counts[id] ?: 0, mine.contains(id)), Ui.lp(a, 10))
        }
    }

    private fun postCard(id: String, m: Map<String, Any?>, likes: Int, liked: Boolean): LinearLayout {
        val username = (m["username"] as? String) ?: ""
        val text = (m["text"] as? String) ?: ""
        val time = (m["createdAt"] as? Long) ?: 0L
        val card = Ui.card(a, 14)

        val head = LinearLayout(a)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(Ui.avatar(a, username, 40))
        val who = LinearLayout(a)
        who.orientation = LinearLayout.VERTICAL
        who.setPadding(Ui.dp(a, 10), 0, 0, 0)
        who.addView(Ui.text(a, "@$username", 15f, Color.WHITE, true))
        who.addView(Ui.text(a, Ui.timeAgo(time), 12f, Ui.MUTED))
        head.addView(who)
        head.setOnClickListener {
            a.startActivity(Intent(a, ProfileActivity::class.java).putExtra("username", username))
        }
        card.addView(head)

        if (text.isNotEmpty()) {
            val body = Ui.text(a, text, 16f, Color.WHITE)
            body.setPadding(0, Ui.dp(a, 10), 0, Ui.dp(a, 6))
            card.addView(body)
        }
        Media.attach(a, card, m)

        val actions = LinearLayout(a)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.gravity = Gravity.CENTER_VERTICAL
        actions.setPadding(0, Ui.dp(a, 8), 0, 0)
        val likeLabel = (if (liked) "❤ " else "♡ ") + likes
        actions.addView(Ui.btn(a, likeLabel, if (liked) 0xFFEE0979.toInt() else Ui.FIELD) {
            toggleLike(id, liked)
        })
        if (username != Fb.username(a)) {
            val chatLp = Ui.wrap()
            chatLp.leftMargin = Ui.dp(a, 8)
            actions.addView(Ui.btn(a, "مراسلة", Ui.FIELD) { Social.startChat(a, username) }, chatLp)
        }
        card.addView(actions)
        return card
    }

    private fun toggleLike(postId: String, liked: Boolean) {
        val me = Fb.uid(a)
        val likeId = "${postId}_$me"
        Thread {
            try {
                if (liked) {
                    Fb.deleteDoc(a, "likes/$likeId")
                } else {
                    Fb.create(a, "likes", likeId, Fb.doc(
                        Pair("postId", Fb.sv(postId)),
                        Pair("uid", Fb.sv(me))
                    ))
                }
                refresh()
            } catch (e: Exception) {
                a.runOnUiThread { status.text = e.message ?: "تعذر تنفيذ الإعجاب" }
            }
        }.start()
    }

    private fun publish() {
        val t = input.text.toString().trim()
        val uri = pendingUri
        if (t.isEmpty() && uri == null) return
        val mime = pendingMime
        input.setText("")
        pendingUri = null
        status.setTextColor(Ui.MUTED)
        status.text = if (uri != null) "جارٍ رفع الوسائط..." else "جارٍ النشر..."
        Thread {
            try {
                var mediaUrl = ""
                var mediaType = ""
                if (uri != null) {
                    mediaUrl = Media.upload(a, uri, mime)
                    mediaType = if (mime.startsWith("video")) "video" else "image"
                }
                val body = Fb.doc(
                    Pair("author", Fb.sv(Fb.uid(a))),
                    Pair("username", Fb.sv(Fb.username(a))),
                    Pair("text", Fb.sv(t)),
                    Pair("media", Fb.sv(mediaUrl)),
                    Pair("mediaType", Fb.sv(mediaType)),
                    Pair("createdAt", Fb.iv(System.currentTimeMillis()))
                )
                Fb.create(a, "posts", null, body)
                a.runOnUiThread { status.text = "" }
                refresh()
            } catch (e: Exception) {
                a.runOnUiThread {
                    status.setTextColor(Color.RED)
                    status.text = e.message ?: "تعذر النشر"
                }
            }
        }.start()
    }
}
