package com.example.imtidad

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class LoginActivity : Activity() {

    private var registerMode = false
    private lateinit var apiKey: EditText
    private lateinit var project: EditText
    private lateinit var user: EditText
    private lateinit var email: EditText
    private lateinit var pass: EditText
    private lateinit var go: Button
    private lateinit var toggleBtn: Button
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Fb.loggedIn(this)) {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
            return
        }
        val pad = Ui.dp(this, 20)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, Ui.dp(this@LoginActivity, 40), pad, pad)
            setBackgroundColor(0xFF0A0E14.toInt())
        }
        col.addView(TextView(this).apply {
            text = "امتداد"; textSize = 34f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        })
        col.addView(TextView(this).apply {
            text = "تواصل بلا حدود"; setTextColor(0xFF8FA3AD.toInt()); gravity = Gravity.CENTER
        })

        apiKey = Ui.input(this, "مفتاح Firebase (Web API Key)")
        project = Ui.input(this, "معرف المشروع (Project ID)")
        apiKey.setText(Fb.apiKey(this))
        project.setText(Fb.projectId(this))
        user = Ui.input(this, "اسم المستخدم (للتسجيل فقط)")
        user.visibility = View.GONE
        email = Ui.input(this, "البريد الإلكتروني")
        email.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        pass = Ui.input(this, "كلمة المرور", password = true)
        go = Ui.btn(this, "تسجيل الدخول") { submit() }
        toggleBtn = Ui.btn(this, "ليس لديك حساب؟ أنشئ حساباً", 0xFF16202C.toInt()) { toggleMode() }
        status = TextView(this).apply { setTextColor(0xFFFF8A80.toInt()); gravity = Gravity.CENTER }

        val views: List<View> = listOf(apiKey, project, user, email, pass, go, toggleBtn, status)
        for (v in views) col.addView(v, Ui.lp(this, 10))

        val scroll = ScrollView(this)
        scroll.addView(col)
        setContentView(scroll)
    }

    private fun toggleMode() {
        registerMode = !registerMode
        user.visibility = if (registerMode) View.VISIBLE else View.GONE
        go.text = if (registerMode) "إنشاء الحساب" else "تسجيل الدخول"
        toggleBtn.text = if (registerMode) "لديك حساب؟ سجّل الدخول" else "ليس لديك حساب؟ أنشئ حساباً"
        status.text = ""
    }

    private fun submit() {
        val key = apiKey.text.toString().trim()
        val pid = project.text.toString().trim()
        val mail = email.text.toString().trim()
        val pw = pass.text.toString()
        val name = user.text.toString().trim().lowercase()

        if (key.isEmpty() || pid.isEmpty()) { status.text = "أدخل مفتاح Firebase ومعرف المشروع"; return }
        if (mail.isEmpty() || pw.length < 6) { status.text = "أدخل بريداً وكلمة مرور (6 أحرف على الأقل)"; return }
        if (registerMode && (name.length < 3 || name.contains(' '))) {
            status.text = "اسم المستخدم 3 أحرف على الأقل بدون مسافات"; return
        }
        Fb.saveConfig(this, key, pid)
        status.setTextColor(0xFF8FA3AD.toInt())
        status.text = "جارٍ التنفيذ..."
        go.isEnabled = false

        Thread {
            try {
                val res = if (registerMode) Fb.signUp(this, mail, pw) else Fb.signIn(this, mail, pw)
                val uid = res.getString("localId")
                val token = res.getString("idToken")
                val refresh = res.getString("refreshToken")
                Fb.saveSession(this, uid, token, refresh, "")

                if (registerMode) {
                    if (Fb.findUserByName(this, name) != null) throw Exception("اسم المستخدم مأخوذ، اختر غيره")
                    Fb.create(this, "users", uid, Fb.doc(Pair("username", Fb.sv(name)), Pair("email", Fb.sv(mail))))
                    Fb.saveSession(this, uid, token, refresh, name)
                } else {
                    val me = Fb.getDoc(this, "users/$uid")
                    val uname = (me?.get("username") as? String) ?: ""
                    Fb.saveSession(this, uid, token, refresh, uname)
                }
                runOnUiThread {
                    startActivity(Intent(this, HomeActivity::class.java))
                    finish()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.setTextColor(0xFFFF8A80.toInt())
                    status.text = e.message ?: "حدث خطأ"
                    go.isEnabled = true
                }
            }
        }.start()
    }
}
