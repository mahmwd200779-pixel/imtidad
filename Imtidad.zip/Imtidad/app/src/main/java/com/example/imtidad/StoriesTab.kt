package com.example.imtidad

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Stories tab: colored text, photo or video stories that last 24 hours. */
class StoriesTab(private val a: Activity) : ScrollView(a), Tab {
    private val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
    private val ringRow = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
    private val swatches = ArrayList<View>()
    private val input: EditText
    private val status: TextView
    private var colorIdx = 0
    private var pendingUri: Uri? = null
    private var pendingMime = ""
    private var lastSig = ""
    @Volatile private var busy = false

    init {
        val pad = Ui.dp(a, 12)
        col.setPadding(pad, pad, pad, pad)

        val composer = Ui.card(a)
        composer.addView(Ui.text(a, "ستوري جديدة (تختفي بعد 24 ساعة)", 14f, Ui.CYAN, true))
        input = Ui.input(a, "اكتب ستوريك...")
        composer.addView(input, Ui.lp(a, 8))

        val swRow = LinearLayout(a)
        swRow.orientation = LinearLayout.HORIZONTAL
        swRow.gravity = Gravity.CENTER_VERTICAL
        for (i in Ui.COLORS.indices) {
            val sw = View(a)
            sw.background = Ui.gradient(a, Ui.COLORS[i][0], Ui.COLORS[i][1], 20)
            sw.setOnClickListener { select(i) }
            swatches.add(sw)
            val swLp = LinearLayout.LayoutParams(Ui.dp(a, 36), Ui.dp(a, 36))
            swLp.setMargins(Ui.dp(a, 4), 0, Ui.dp(a, 4), 0)
            swRow.addView(sw, swLp)
        }
        composer.addView(swRow, Ui.lp(a, 10))
        composer.addView(Media.buttons(a, { type -> pickGallery(type) }, { video -> capture(video) }), Ui.lp(a, 8))
        composer.addView(Ui.btn(a, "نشر الستوري") { publish() }, Ui.lp(a, 10))
        status = Ui.text(a, "", 12f, Color.RED)
        composer.addView(status)
        col.addView(composer)

        col.addView(Ui.text(a, "الستوري الآن", 16f, Color.WHITE, true), Ui.lp(a, 16))
        val scroll = HorizontalScrollView(a)
        scroll.addView(ringRow)
        col.addView(scroll, Ui.lp(a, 10))

        addView(col)
        select(0)
    }

    private fun select(i: Int) {
        colorIdx = i
        for (j in swatches.indices) swatches[j].alpha = if (j == i) 1f else 0.35f
    }

    private fun pickGallery(type: String) {
        MediaPicker.gallery(a, type) { uri, mime -> setPending(uri, mime) }
    }

    private fun capture(video: Boolean) {
        val ok = MediaPicker.capture(a, video) { uri, mime -> setPending(uri, mime) }
        if (!ok) status.text = "تعذر فتح الكاميرا على هذا الجهاز"
    }

    private fun setPending(uri: Uri, mime: String) {
        pendingUri = uri
        pendingMime = mime
        status.setTextColor(Ui.MUTED)
        status.text = if (mime.startsWith("video")) "🎥 فيديو جاهز للستوري" else "🖼 صورة جاهزة للستوري"
    }

    override fun refresh() {
        if (busy) return
        busy = true
        Thread {
            try {
                val now = System.currentTimeMillis()
                val all = Fb.queryAll(a, "stories", 200, "createdAt")
                val latest = LinkedHashMap<String, Long>()
                for ((_, m) in all) {
                    val u = (m["username"] as? String) ?: continue
                    val t = (m["createdAt"] as? Long) ?: 0L
                    if (now - t > Ui.DAY_MS) continue
                    val prev = latest[u] ?: 0L
                    if (t > prev) latest[u] = t
                }
                val users = latest.entries.sortedByDescending { it.value }.map { it.key }
                val sig = users.joinToString("|")
                if (sig != lastSig) {
                    lastSig = sig
                    a.runOnUiThread { renderRing(users) }
                }
            } catch (e: Exception) {
                a.runOnUiThread { status.text = e.message ?: "" }
            } finally {
                busy = false
            }
        }.start()
    }

    private fun renderRing(users: List<String>) {
        ringRow.removeAllViews()
        if (users.isEmpty()) {
            ringRow.addView(Ui.text(a, "لا توجد ستوريات نشطة الآن", 13f, Ui.MUTED))
            return
        }
        for (u in users) {
            val item = LinearLayout(a)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER_HORIZONTAL
            item.setPadding(Ui.dp(a, 6), 0, Ui.dp(a, 6), 0)
            item.addView(Ui.ring(a, u, 72))
            item.addView(Ui.text(a, "@$u", 12f, Color.WHITE))
            item.setOnClickListener {
                a.startActivity(Intent(a, StoryViewActivity::class.java).putExtra("username", u))
            }
            ringRow.addView(item)
        }
    }

    private fun publish() {
        val t = input.text.toString().trim()
        val uri = pendingUri
        if (t.isEmpty() && uri == null) {
            status.setTextColor(Color.RED)
            status.text = "اكتب نصاً أو اختر وسائط"
            return
        }
        val mime = pendingMime
        input.setText("")
        pendingUri = null
        status.setTextColor(Ui.MUTED)
        status.text = if (uri != null) "جارٍ رفع الوسائط..." else "جارٍ النشر..."
        val color = colorIdx.toLong()
        Thread {
            try {
                var mediaUrl = ""
                var mediaType = ""
                if (uri != null) {
                    mediaUrl = Media.upload(a, uri, mime)
                    mediaType = if (mime.startsWith("video")) "video" else "image"
                }
                val body = Fb.doc(
                    Pair("author", Fb.sv(Fb.uid(a))),
                    Pair("username", Fb.sv(Fb.username(a))),
                    Pair("text", Fb.sv(t)),
                    Pair("color", Fb.iv(color)),
                    Pair("media", Fb.sv(mediaUrl)),
                    Pair("mediaType", Fb.sv(mediaType)),
                    Pair("createdAt", Fb.iv(System.currentTimeMillis()))
                )
                Fb.create(a, "stories", null, body)
                a.runOnUiThread { status.text = "" }
                refresh()
            } catch (e: Exception) {
                a.runOnUiThread {
                    status.setTextColor(Color.RED)
                    status.text = e.message ?: "تعذر النشر"
                }
            }
        }.start()
    }
}
