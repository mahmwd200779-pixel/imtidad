package com.example.imtidad

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class FbException(message: String, val code: Int) : Exception(message)

/** Firebase over plain REST (no SDK): Auth + Firestore. */
object Fb {
    private fun prefs(c: Context) = c.getSharedPreferences("imtidad", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = prefs(c).getString("apiKey", "") ?: ""
    fun projectId(c: Context): String = prefs(c).getString("projectId", "") ?: ""
    fun uid(c: Context): String = prefs(c).getString("uid", "") ?: ""
    fun username(c: Context): String = prefs(c).getString("username", "") ?: ""
    fun idToken(c: Context): String = prefs(c).getString("idToken", "") ?: ""
    private fun refresh(c: Context): String = prefs(c).getString("refresh", "") ?: ""

    fun loggedIn(c: Context): Boolean = uid(c).isNotEmpty() && refresh(c).isNotEmpty()

    fun saveConfig(c: Context, key: String, project: String) {
        prefs(c).edit().putString("apiKey", key.trim()).putString("projectId", project.trim()).apply()
    }

    fun saveSession(c: Context, uid: String, token: String, refresh: String, username: String) {
        prefs(c).edit().putString("uid", uid).putString("idToken", token)
            .putString("refresh", refresh).putString("username", username).apply()
    }

    fun logout(c: Context) {
        prefs(c).edit().remove("uid").remove("idToken").remove("refresh").remove("username").apply()
    }

    private fun send(method: String, url: String, body: String?, token: String?, form: Boolean = false): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 15000
        conn.readTimeout = 20000
        conn.setRequestProperty("Content-Type", if (form) "application/x-www-form-urlencoded" else "application/json")
        if (!token.isNullOrEmpty()) conn.setRequestProperty("Authorization", "Bearer $token")
        if (body != null) {
            conn.doOutput = true
            conn.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else (conn.errorStream ?: conn.inputStream)
        val text = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) throw FbException(text, code)
        return text
    }

    fun readableError(raw: String?): String {
        val msg = try { JSONObject(raw ?: "").getJSONObject("error").getString("message") } catch (e: Exception) { raw ?: "خطأ" }
        return when {
            msg.contains("EMAIL_EXISTS") -> "هذا البريد مسجل مسبقاً"
            msg.contains("INVALID_LOGIN_CREDENTIALS") || msg.contains("INVALID_PASSWORD") || msg.contains("EMAIL_NOT_FOUND") ->
                "البريد أو كلمة المرور غير صحيحة"
            msg.contains("WEAK_PASSWORD") -> "كلمة المرور قصيرة (6 أحرف على الأقل)"
            msg.contains("INVALID_EMAIL") -> "صيغة البريد غير صحيحة"
            msg.contains("API_KEY") -> "مفتاح Firebase غير صحيح"
            msg.contains("PERMISSION_DENIED") -> "لا توجد صلاحية: راجع قواعد Firestore"
            else -> msg
        }
    }

    private fun authCall(c: Context, action: String, email: String, password: String): JSONObject {
        val body = JSONObject().put("email", email).put("password", password).put("returnSecureToken", true).toString()
        val url = "https://identitytoolkit.googleapis.com/v1/accounts:$action?key=${apiKey(c)}"
        try {
            return JSONObject(send("POST", url, body, null))
        } catch (e: FbException) {
            throw FbException(readableError(e.message), e.code)
        }
    }

    fun signUp(c: Context, email: String, password: String): JSONObject = authCall(c, "signUp", email, password)
    fun signIn(c: Context, email: String, password: String): JSONObject = authCall(c, "signInWithPassword", email, password)

    private fun refreshIdToken(c: Context): Boolean {
        val r = refresh(c)
        if (r.isEmpty()) return false
        val res = JSONObject(send("POST", "https://securetoken.googleapis.com/v1/token?key=${apiKey(c)}",
            "grant_type=refresh_token&refresh_token=$r", null, form = true))
        prefs(c).edit().putString("idToken", res.getString("id_token")).putString("refresh", res.getString("refresh_token")).apply()
        return true
    }

    private fun <T> authed(c: Context, block: (String) -> T): T {
        return try {
            block(idToken(c))
        } catch (e: FbException) {
            if (e.code == 401 && refreshIdToken(c)) block(idToken(c)) else throw e
        }
    }

    private fun base(c: Context): String =
        "https://firestore.googleapis.com/v1/projects/${projectId(c)}/databases/(default)/documents"

    fun sv(s: String): JSONObject = JSONObject().put("stringValue", s)
    fun iv(n: Long): JSONObject = JSONObject().put("integerValue", n.toString())
    fun av(list: List<String>): JSONObject {
        val values = JSONArray()
        for (s in list) values.put(sv(s))
        return JSONObject().put("arrayValue", JSONObject().put("values", values))
    }

    fun doc(vararg pairs: Pair<String, JSONObject>): String {
        val f = JSONObject()
        for ((k, v) in pairs) f.put(k, v)
        return JSONObject().put("fields", f).toString()
    }

    /** Creates a document (auto id when docId is null). Returns false if it already exists. */
    fun create(c: Context, collection: String, docId: String?, body: String): Boolean = authed(c) { t ->
        val q = if (docId != null) "?documentId=" + URLEncoder.encode(docId, "UTF-8") else ""
        try {
            send("POST", "${base(c)}/$collection$q", body, t)
            true
        } catch (e: FbException) {
            if (e.code == 409) false else throw e
        }
    }

    fun getDoc(c: Context, path: String): Map<String, Any?>? = authed(c) { t ->
        try {
            parse(JSONObject(send("GET", "${base(c)}/$path", null, t)).optJSONObject("fields"))
        } catch (e: FbException) {
            if (e.code == 404) null else throw e
        }
    }

    fun query(c: Context, collection: String, field: String, op: String, value: JSONObject, limit: Int = 100): List<Pair<String, Map<String, Any?>>> =
        authed(c) { t ->
            val sq = JSONObject()
                .put("from", JSONArray().put(JSONObject().put("collectionId", collection)))
                .put("where", JSONObject().put("fieldFilter", JSONObject()
                    .put("field", JSONObject().put("fieldPath", field))
                    .put("op", op)
                    .put("value", value)))
                .put("limit", limit)
            val res = JSONArray(send("POST", "${base(c)}:runQuery", JSONObject().put("structuredQuery", sq).toString(), t))
            val out = ArrayList<Pair<String, Map<String, Any?>>>()
            for (i in 0 until res.length()) {
                val d = res.getJSONObject(i).optJSONObject("document") ?: continue
                val id = d.getString("name").substringAfterLast('/')
                out.add(Pair(id, parse(d.optJSONObject("fields"))))
            }
            out
        }

    fun findUserByName(c: Context, name: String): Pair<String, Map<String, Any?>>? =
        query(c, "users", "username", "EQUAL", sv(name), 1).firstOrNull()

    fun parse(fields: JSONObject?): Map<String, Any?> {
        val m = HashMap<String, Any?>()
        if (fields == null) return m
        val keys = fields.keys()
        while (keys.hasNext()) {
            val k = keys.next() as String
            m[k] = value(fields.getJSONObject(k))
        }
        return m
    }

    private fun value(o: JSONObject): Any? = when {
        o.has("stringValue") -> o.getString("stringValue")
        o.has("integerValue") -> o.getString("integerValue").toLong()
        o.has("arrayValue") -> {
            val arr = o.getJSONObject("arrayValue").optJSONArray("values") ?: JSONArray()
            (0 until arr.length()).map { value(arr.getJSONObject(it)) }
        }
        else -> null
    }
}
