package com.example.imtidad

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class ChatActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private var chatId = ""
    private var other = ""
    private lateinit var box: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private var lastSig = ""
    @Volatile private var busy = false

    private val poll = object : Runnable {
        override fun run() {
            loadMessages()
            ui.postDelayed(this, 2000L)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        chatId = intent.getStringExtra("chatId") ?: ""
        other = intent.getStringExtra("other") ?: ""

        val pad = Ui.dp(this, 12)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0A0E14.toInt())
            setPadding(pad, pad, pad, pad)
        }
        col.addView(TextView(this).apply { text = "@$other"; textSize = 20f; setTextColor(Color.WHITE) })

        scroll = ScrollView(this)
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(box)
        col.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = Ui.input(this, "اكتب رسالة...")
        row.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sendBtn = Ui.btn(this, "إرسال") { send() }
        val sendLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        sendLp.leftMargin = Ui.dp(this, 8)
        row.addView(sendBtn, sendLp)
        col.addView(row, Ui.lp(this, 8))

        setContentView(col)
    }

    override fun onResume() {
        super.onResume()
        ui.removeCallbacks(poll)
        ui.post(poll)
    }

    override fun onPause() {
        ui.removeCallbacks(poll)
        super.onPause()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun loadMessages() {
        if (busy || chatId.isEmpty()) return
        busy = true
        Thread {
            try {
                val docs = Fb.query(this, "messages", "chatId", "EQUAL", Fb.sv(chatId), 200)
                val sorted = docs.sortedBy { (it.second["time"] as? Long) ?: 0L }
                val sig = sorted.joinToString("|") { it.first }
                if (sig != lastSig) {
                    lastSig = sig
                    runOnUiThread { render(sorted) }
                }
            } catch (e: Exception) {
                // ignore; next poll retries
            } finally {
                busy = false
            }
        }.start()
    }

    private fun render(msgs: List<Pair<String, Map<String, Any?>>>) {
        box.removeAllViews()
        val me = Fb.uid(this)
        for ((_, m) in msgs) {
            val mine = m["from"] == me
            val msgText = (m["text"] as? String) ?: ""
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = if (mine) Gravity.END else Gravity.START
            }
            val bubble = TextView(this).apply {
                text = msgText
                textSize = 16f
                setTextColor(Color.WHITE)
                val p = Ui.dp(this@ChatActivity, 12)
                val q = Ui.dp(this@ChatActivity, 8)
                setPadding(p, q, p, q)
                background = Ui.rounded(this@ChatActivity, if (mine) 0xFF2F80FF.toInt() else 0xFF1B2330.toInt(), 14)
            }
            val bubbleLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            bubbleLp.topMargin = Ui.dp(this, 6)
            row.addView(bubble, bubbleLp)
            box.addView(row)
        }
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun send() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        val body = Fb.doc(
            Pair("chatId", Fb.sv(chatId)),
            Pair("from", Fb.sv(Fb.uid(this))),
            Pair("text", Fb.sv(t)),
            Pair("time", Fb.iv(System.currentTimeMillis()))
        )
        Thread {
            try {
                Fb.create(this, "messages", null, body)
                loadMessages()
            } catch (e: Exception) {
                runOnUiThread { toast(e.message ?: "تعذر الإرسال") }
            }
        }.start()
    }
}
