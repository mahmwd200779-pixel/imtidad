package com.example.imtidad

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView

/** Profile page. username == own name (or empty) shows the editable own profile. */
class ProfileView(private val a: Activity, private val username: String) : ScrollView(a), Tab {
    private val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
    @Volatile private var busy = false
    private var lastLoad = 0L

    init {
        val pad = Ui.dp(a, 14)
        col.setPadding(pad, pad, pad, Ui.dp(a, 28))
        addView(col)
    }

    override fun refresh() = load(false)

    fun load(force: Boolean) {
        val now = System.currentTimeMillis()
        if (!force && now - lastLoad < 15000L) return
        if (busy) return
        busy = true
        lastLoad = now
        Thread {
            try {
                val mine = username.isEmpty() || username == Fb.username(a)
                val uid: String
                val info: Map<String, Any?>
                if (mine) {
                    uid = Fb.uid(a)
                    info = Fb.getDoc(a, "users/$uid") ?: emptyMap()
                } else {
                    val found = Fb.findUserByName(a, username) ?: throw Exception("المستخدم غير موجود")
                    uid = found.first
                    info = found.second
                }
                val posts = Fb.query(a, "posts", "author", "EQUAL", Fb.sv(uid), 100)
                    .sortedByDescending { (it.second["createdAt"] as? Long) ?: 0L }
                a.runOnUiThread { render(uid, info, posts, mine) }
            } catch (e: Exception) {
                a.runOnUiThread {
                    col.removeAllViews()
                    col.addView(Ui.text(a, e.message ?: "خطأ", 14f, Color.RED))
                }
            } finally {
                busy = false
            }
        }.start()
    }

    private fun render(uid: String, info: Map<String, Any?>, posts: List<Row>, mine: Boolean) {
        col.removeAllViews()
        val uname = (info["username"] as? String) ?: username
        val display = (info["displayName"] as? String).orEmpty().ifBlank { "@$uname" }
        val bio = (info["bio"] as? String).orEmpty()

        val header = Ui.card(a, 18)
        header.gravity = Gravity.CENTER_HORIZONTAL
        header.addView(Ui.avatar(a, uname, 96))
        header.addView(Ui.text(a, display, 20f, Color.WHITE, true).apply { gravity = Gravity.CENTER }, Ui.lp(a, 10))
        header.addView(Ui.text(a, "@$uname", 14f, Ui.MUTED).apply { gravity = Gravity.CENTER })
        if (bio.isNotBlank()) {
            header.addView(Ui.text(a, bio, 15f, Color.WHITE).apply { gravity = Gravity.CENTER }, Ui.lp(a, 10))
        }

        val stats = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        stats.addView(stat("${posts.size}", "منشور"))
        header.addView(stats, Ui.lp(a, 14))

        if (mine) {
            header.addView(Ui.btn(a, "تعديل الملف الشخصي", Ui.FIELD) { editDialog(uid, uname, info) }, Ui.lp(a, 12))
            header.addView(Ui.btn(a, "تسجيل الخروج", 0xFF3A2230.toInt()) { logout() }, Ui.lp(a, 8))
        } else {
            header.addView(Ui.btn(a, "مراسلة @$uname") { Social.startChat(a, uname) }, Ui.lp(a, 12))
        }
        col.addView(header, Ui.lp(a, 0))

        col.addView(Ui.text(a, "المنشورات", 16f, Color.WHITE, true), Ui.lp(a, 18))
        if (posts.isEmpty()) {
            col.addView(Ui.text(a, "لا توجد منشورات بعد", 13f, Ui.MUTED), Ui.lp(a, 8))
        }
        for ((_, m) in posts) {
            col.addView(simplePost(m), Ui.lp(a, 8))
        }
    }

    private fun stat(n: String, label: String): LinearLayout {
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.setPadding(Ui.dp(a, 18), 0, Ui.dp(a, 18), 0)
        box.addView(Ui.text(a, n, 18f, Ui.CYAN, true).apply { gravity = Gravity.CENTER })
        box.addView(Ui.text(a, label, 12f, Ui.MUTED).apply { gravity = Gravity.CENTER })
        return box
    }

    private fun simplePost(m: Map<String, Any?>): LinearLayout {
        val card = Ui.card(a, 12)
        val t = (m["text"] as? String) ?: ""
        if (t.isNotEmpty()) card.addView(Ui.text(a, t, 15f, Color.WHITE))
        Media.attach(a, card, m)
        val time = Ui.text(a, Ui.timeAgo((m["createdAt"] as? Long) ?: 0L), 11f, Ui.MUTED)
        time.setPadding(0, Ui.dp(a, 6), 0, 0)
        card.addView(time)
        return card
    }

    private fun editDialog(uid: String, uname: String, info: Map<String, Any?>) {
        val pad = Ui.dp(a, 16)
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad, pad, pad)
        val nameField = Ui.input(a, "الاسم الظاهر")
        nameField.setText((info["displayName"] as? String).orEmpty())
        val bioField = Ui.input(a, "نبذة عنك")
        bioField.setText((info["bio"] as? String).orEmpty())
        box.addView(nameField)
        box.addView(bioField, Ui.lp(a, 10))

        AlertDialog.Builder(a)
            .setTitle("تعديل الملف الشخصي")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val dn = nameField.text.toString().trim()
                val bi = bioField.text.toString().trim()
                val email = (info["email"] as? String).orEmpty()
                Thread {
                    try {
                        // Firestore REST has no in-place update here, so replace the profile document.
                        Fb.deleteDoc(a, "users/$uid")
                        Fb.create(a, "users", uid, Fb.doc(
                            Pair("username", Fb.sv(uname)),
                            Pair("email", Fb.sv(email)),
                            Pair("displayName", Fb.sv(dn)),
                            Pair("bio", Fb.sv(bi))
                        ))
                        load(true)
                    } catch (e: Exception) {
                        a.runOnUiThread { Social.toast(a, e.message ?: "تعذر الحفظ") }
                    }
                }.start()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun logout() {
        Fb.logout(a)
        a.startActivity(
            Intent(a, LoginActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        )
        a.finish()
    }
}
